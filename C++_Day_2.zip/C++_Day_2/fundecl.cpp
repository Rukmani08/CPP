// function declaration must

#include<iostream>
using namespace std;

int main()
{
	disp(); // error
	return 0;
}
void disp()
{
	cout<<"in disp"<<endl;
}