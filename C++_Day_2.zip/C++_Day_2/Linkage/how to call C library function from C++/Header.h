#ifdef __cplusplus
extern "C" {
#endif
void  disp(int);
#ifdef __cplusplus
}
#endif