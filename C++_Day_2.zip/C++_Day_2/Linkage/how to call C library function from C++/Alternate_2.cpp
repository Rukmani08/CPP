
#include <iostream>
#include"d:\MyCpp\client\Header.h"
using namespace std;
int main()
{
    cout << "Before calling"<<endl;
    disp(100);
    cout << "After calling" << endl;

}

