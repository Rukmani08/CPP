
#include "Header.h"
#include<stdio.h>
void disp(int k)
{
	printf("%d\n", k);
}
