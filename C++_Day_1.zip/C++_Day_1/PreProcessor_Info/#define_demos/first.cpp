#include<iostream>
using namespace std;
#define SIZE 5
int main()
{
	int arr[SIZE] = { 10,20,30,40,50 };
	int i;
	for (i = 0; i < SIZE; i++)
	{
		cout << arr[i] << endl;
	}

	return 0;
}