#include<iostream>
using namespace std;

#include "e:\temp1\myheader.h"

void main()
{
	myc<int>m(30);
	m.disp();
}